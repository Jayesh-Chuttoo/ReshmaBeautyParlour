<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Handle Form POST Actions
$message = '';
$msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // --- ORDER ACTIONS (Delete disabled) ---
    if ($action === 'update_order_status') {
        $orderId = intval($_POST['order_id'] ?? 0);
        $newStatus = trim($_POST['status'] ?? '');
        $allowedStatuses = ['Pending Verification', 'Processing', 'Out for Delivery', 'Delivered', 'Cancelled', 'Refunded'];

        if ($orderId > 0 && in_array($newStatus, $allowedStatuses)) {
            $stmt = $pdo->prepare("UPDATE orders SET payment_status = ? WHERE id = ?");
            $success = $stmt->execute([$newStatus, $orderId]);
            $message = $success ? "Order #{$orderId} status updated to '{$newStatus}'!" : 'Failed to update order status.';
            $msgType = $success ? 'success' : 'error';
        } else {
            $message = 'Invalid status selected.';
            $msgType = 'error';
        }
    }

    // --- FULFILLMENT / DELIVERY METHOD ACTIONS (Delete disabled) ---
    elseif ($action === 'add_fulfillment' || $action === 'edit_fulfillment') {
        $id = $_POST['fulfillment_id'] ?? null;
        $code = strtolower(trim($_POST['code'] ?? ''));
        $name = trim($_POST['name'] ?? '');
        $fee = floatval($_POST['fee'] ?? 0);
        $description = trim($_POST['description'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if (!empty($name) && !empty($code)) {
            if ($action === 'add_fulfillment') {
                $stmt = $pdo->prepare("INSERT INTO fulfillment_methods (code, name, fee, description, is_active) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), fee=VALUES(fee), description=VALUES(description), is_active=VALUES(is_active)");
                $success = $stmt->execute([$code, $name, $fee, $description, $isActive]);
            } else {
                $stmt = $pdo->prepare("UPDATE fulfillment_methods SET code=?, name=?, fee=?, description=?, is_active=? WHERE id=?");
                $success = $stmt->execute([$code, $name, $fee, $description, $isActive, $id]);
            }
            $message = $success ? 'Fulfillment method saved successfully!' : 'Failed to save fulfillment method.';
            $msgType = $success ? 'success' : 'error';
        } else {
            $message = 'Code and Name are required for fulfillment methods.';
            $msgType = 'error';
        }
    }

    // --- PRODUCT ACTIONS (Delete disabled) ---
    elseif ($action === 'add_product' || $action === 'edit_product') {
        $id = $_POST['product_id'] ?? null;
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = floatval($_POST['price'] ?? 0);

        $stockS = intval($_POST['stock_s'] ?? 0);
        $stockM = intval($_POST['stock_m'] ?? 0);
        $stockL = intval($_POST['stock_l'] ?? 0);
        $totalStock = $stockS + $stockM + $stockL;

        $sizesJson = json_encode(['S' => $stockS, 'M' => $stockM, 'L' => $stockL]);
        $status = $_POST['status'] ?? 'available';
        $file = $_FILES['product_image'] ?? null;

        if (!empty($name) && $price >= 0) {
            if ($action === 'add_product') {
                $result = addProductWithSizes($pdo, $name, $description, $price, $totalStock, $sizesJson, $status, $file);
            } else {
                $result = updateProductWithSizes($pdo, $id, $name, $description, $price, $totalStock, $sizesJson, $status, $file);
            }
            $message = $result['message'];
            $msgType = $result['success'] ? 'success' : 'error';
        } else {
            $message = 'Please provide a valid product name and price.';
            $msgType = 'error';
        }
    } elseif ($action === 'toggle_product_status') {
        $id = intval($_POST['product_id'] ?? 0);
        $newStatus = $_POST['status'] === 'sold' ? 'available' : 'sold';
        $stmt = $pdo->prepare("UPDATE products SET status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $id]);
        $message = 'Product status updated!';
        $msgType = 'success';
    }

    // --- SERVICE ACTIONS (Delete disabled) ---
    elseif ($action === 'add_service' || $action === 'edit_service') {
        $id = $_POST['service_id'] ?? null;
        $serviceName = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $allowsDisplacement = isset($_POST['allows_displacement']) ? 1 : 0;
        $displacementFee = floatval($_POST['displacement_fee'] ?? 0);
        $file = $_FILES['service_image'] ?? null;

        $imagePath = null;
        if ($file && $file['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'service_' . uniqid() . '.' . $ext;
            $uploadDir = __DIR__ . '/../public/uploads/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
                $imagePath = 'uploads/' . $filename;
            }
        }

        if (!empty($serviceName)) {
            if ($action === 'add_service') {
                $stmt = $pdo->prepare("INSERT INTO services (title, description, price, image, allows_displacement, displacement_fee) VALUES (?, ?, ?, ?, ?, ?)");
                $success = $stmt->execute([$serviceName, $description, $price, $imagePath, $allowsDisplacement, $displacementFee]);
            } else {
                if ($imagePath) {
                    $stmt = $pdo->prepare("UPDATE services SET title=?, description=?, price=?, image=?, allows_displacement=?, displacement_fee=? WHERE id=?");
                    $success = $stmt->execute([$serviceName, $description, $price, $imagePath, $allowsDisplacement, $displacementFee, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE services SET title=?, description=?, price=?, allows_displacement=?, displacement_fee=? WHERE id=?");
                    $success = $stmt->execute([$serviceName, $description, $price, $allowsDisplacement, $displacementFee, $id]);
                }
            }
            $message = $success ? 'Service saved successfully!' : 'Failed to save service.';
            $msgType = $success ? 'success' : 'error';
        } else {
            $message = 'Service name is required.';
            $msgType = 'error';
        }
    }

    // --- BOOKING ACTIONS ---
    elseif ($action === 'add_booking') {
        $serviceName = $_POST['service_name'] ?? '';
        $clientName = $_POST['client_name'] ?? '';
        $contact = $_POST['contact'] ?? '';
        $peopleCount = intval($_POST['people_count'] ?? 1);
        $onsiteVisit = isset($_POST['onsite_visit']) ? 1 : 0;
        $bookingDate = $_POST['booking_date'] ?? date('Y-m-d H:i:s');

        $success = insertBooking($pdo, $serviceName, $clientName, $contact, $peopleCount, $onsiteVisit, $bookingDate);
        $message = $success ? 'Booking created successfully!' : 'Failed to create booking.';
        $msgType = $success ? 'success' : 'error';
    }
}

// Fetch Records Safely
$products = function_exists('getAllProducts') ? getAllProducts($pdo) : [];
$services = function_exists('getAllServices') ? getAllServices($pdo) : [];
$bookings = function_exists('getAllBookings') ? getAllBookings($pdo) : [];
$users = function_exists('getAllUsers') ? getAllUsers($pdo) : [];

// Fetch Orders with Items
$orders = [];
try {
    $orderStmt = $pdo->query("SELECT * FROM orders ORDER BY id DESC");
    $orders = $orderStmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($orders as &$ord) {
        $itemStmt = $pdo->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
        $itemStmt->execute([$ord['id']]);
        $ord['items'] = $itemStmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
}

// Fetch Fulfillment Methods
$fulfillmentMethods = [];
try {
    $fStmt = $pdo->query("SELECT * FROM fulfillment_methods ORDER BY id ASC");
    $fulfillmentMethods = $fStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reshma Beauty Parlour - Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body class="bg-gray-50 font-sans antialiased text-gray-900">
    <div class="min-h-screen flex flex-col">
        <!-- Header -->
        <header class="bg-indigo-900 text-white shadow-md sticky top-0 z-30">
            <div class="max-w-7xl mx-auto px-4 py-3.5 flex flex-col sm:flex-row justify-between items-center gap-2">
                <div class="flex items-center space-x-3">
                    <i class="fa-solid fa-spa text-2xl text-pink-400"></i>
                    <h1 class="text-lg sm:text-xl font-bold tracking-wide">Reshma Beauty Parlour <span class="text-xs bg-indigo-700 px-2 py-0.5 rounded text-indigo-200 ml-1">Admin Panel</span></h1>
                </div>
                <div class="text-xs sm:text-sm text-indigo-200 flex items-center"><i class="fa-solid fa-user-shield mr-1.5"></i> Administrator</div>
            </div>
        </header>

        <!-- Main Container -->
        <main class="max-w-7xl mx-auto px-3 sm:px-4 py-6 flex-1 w-full">
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg shadow-sm text-sm <?= $msgType === 'success' ? 'bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700' : 'bg-red-100 border-l-4 border-red-500 text-red-700' ?>">
                    <p><i class="fa-solid <?= $msgType === 'success' ? 'fa-circle-check' : 'fa-triangle-exclamation' ?> mr-2"></i><?= htmlspecialchars($message) ?></p>
                </div>
            <?php endif; ?>

            <!-- Navigation Tabs -->
            <div class="flex border-b border-gray-200 mb-6 space-x-2 sm:space-x-4 overflow-x-auto pb-2 scrollbar-none">
                <button onclick="switchTab('orders')" id="btn-orders" class="tab-btn px-3 sm:px-4 py-2 font-medium text-xs sm:text-sm text-indigo-600 border-b-2 border-indigo-600 focus:outline-none whitespace-nowrap"><i class="fa-solid fa-bag-shopping mr-1.5"></i> Orders (<?= count($orders) ?>)</button>
                <button onclick="switchTab('delivery')" id="btn-delivery" class="tab-btn px-3 sm:px-4 py-2 font-medium text-xs sm:text-sm text-gray-500 hover:text-indigo-600 focus:outline-none whitespace-nowrap"><i class="fa-solid fa-truck-fast mr-1.5"></i> Delivery Rates</button>
                <button onclick="switchTab('products')" id="btn-products" class="tab-btn px-3 sm:px-4 py-2 font-medium text-xs sm:text-sm text-gray-500 hover:text-indigo-600 focus:outline-none whitespace-nowrap"><i class="fa-solid fa-box-open mr-1.5"></i> Products (<?= count($products) ?>)</button>
                <button onclick="switchTab('services')" id="btn-services" class="tab-btn px-3 sm:px-4 py-2 font-medium text-xs sm:text-sm text-gray-500 hover:text-indigo-600 focus:outline-none whitespace-nowrap"><i class="fa-solid fa-scissors mr-1.5"></i> Services (<?= count($services) ?>)</button>
                <button onclick="switchTab('bookings')" id="btn-bookings" class="tab-btn px-3 sm:px-4 py-2 font-medium text-xs sm:text-sm text-gray-500 hover:text-indigo-600 focus:outline-none whitespace-nowrap"><i class="fa-solid fa-calendar-check mr-1.5"></i> Bookings (<?= count($bookings) ?>)</button>
                <button onclick="switchTab('users')" id="btn-users" class="tab-btn px-3 sm:px-4 py-2 font-medium text-xs sm:text-sm text-gray-500 hover:text-indigo-600 focus:outline-none whitespace-nowrap"><i class="fa-solid fa-users mr-1.5"></i> Users (<?= count($users) ?>)</button>
            </div>

            <!-- TAB 1: ORDERS MANAGEMENT -->
            <div id="tab-orders" class="tab-content space-y-4 sm:space-y-6">
                <div class="flex justify-between items-center">
                    <h2 class="text-lg sm:text-xl font-bold text-gray-800">Customer Orders & Status Management</h2>
                </div>

                <div class="grid grid-cols-1 gap-4">
                    <?php if (empty($orders)): ?>
                        <div class="bg-white p-6 rounded-xl text-center text-gray-500 border border-gray-100 shadow-sm">No orders recorded yet.</div>
                        <?php else: foreach ($orders as $ord):
                            $status = $ord['payment_status'] ?? 'Pending Verification';
                            $statusColors = [
                                'Pending Verification' => 'bg-amber-100 text-amber-800 border-amber-300',
                                'Processing'           => 'bg-blue-100 text-blue-800 border-blue-300',
                                'Out for Delivery'     => 'bg-purple-100 text-purple-800 border-purple-300',
                                'Delivered'            => 'bg-emerald-100 text-emerald-800 border-emerald-300',
                                'Cancelled'            => 'bg-red-100 text-red-800 border-red-300',
                                'Refunded'             => 'bg-gray-200 text-gray-800 border-gray-300',
                            ];
                            $badgeClass = $statusColors[$status] ?? 'bg-gray-100 text-gray-700';
                            $subtotal = floatval($ord['subtotal'] ?? 0);
                            $shipping = floatval($ord['shipping_fee'] ?? 0);
                            $grandTotal = $subtotal + $shipping;
                        ?>
                            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4 sm:p-5 space-y-4">
                                <!-- Order Header -->
                                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-gray-100">
                                    <div>
                                        <span class="font-mono font-bold text-indigo-600 text-base">Order #<?= $ord['id'] ?></span>
                                        <span class="text-xs text-gray-400 ml-2"><i class="fa-regular fa-clock mr-1"></i><?= $ord['created_at'] ?? 'N/A' ?></span>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <span class="px-3 py-1 text-xs rounded-full font-semibold border <?= $badgeClass ?>"><?= htmlspecialchars($status) ?></span>
                                    </div>
                                </div>

                                <!-- Customer & Fulfillment Details -->
                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs sm:text-sm bg-gray-50 p-3 rounded-lg">
                                    <div>
                                        <span class="text-gray-500 block text-[11px] uppercase font-semibold">Customer</span>
                                        <strong class="text-gray-800"><?= htmlspecialchars($ord['customer_name'] ?? 'Guest') ?></strong>
                                        <div class="text-gray-500 text-xs"><?= htmlspecialchars($ord['email'] ?? '') ?></div>
                                        <div class="text-indigo-600 text-xs font-mono"><i class="fa-solid fa-phone mr-1"></i><?= htmlspecialchars($ord['phone_number'] ?? 'N/A') ?></div>
                                    </div>
                                    <div>
                                        <span class="text-gray-500 block text-[11px] uppercase font-semibold">Fulfillment Method</span>
                                        <strong class="text-purple-700"><?= htmlspecialchars($ord['delivery_mode'] ?? 'Store Pickup') ?></strong>
                                    </div>
                                    <div>
                                        <span class="text-gray-500 block text-[11px] uppercase font-semibold">Payment Summary</span>
                                        <div class="text-gray-600 text-xs">Subtotal: Rs <?= number_format($subtotal, 2) ?></div>
                                        <div class="text-gray-600 text-xs">Fulfillment Fee: Rs <?= number_format($shipping, 2) ?></div>
                                        <div class="text-emerald-700 font-bold text-sm">Total: Rs <?= number_format($grandTotal, 2) ?></div>
                                    </div>
                                </div>

                                <!-- Purchased Items List -->
                                <div>
                                    <h4 class="text-xs font-bold text-gray-500 uppercase mb-2">Order Items</h4>
                                    <div class="space-y-1.5">
                                        <?php if (!empty($ord['items'])): foreach ($ord['items'] as $item): ?>
                                                <div class="flex justify-between items-center text-xs bg-white p-2 rounded border border-gray-100">
                                                    <span><strong><?= htmlspecialchars($item['name']) ?></strong> <span class="text-indigo-600 font-mono">(Size: <?= htmlspecialchars($item['size']) ?>)</span> × <?= $item['quantity'] ?></span>
                                                    <span class="font-medium text-gray-700">Rs <?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                                                </div>
                                            <?php endforeach;
                                        else: ?>
                                            <p class="text-xs text-gray-400 italic">No specific items listed.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Actions Row: Status Change & Proof View -->
                                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pt-3 border-t border-gray-100">
                                    <!-- Proof Button -->
                                    <?php if (!empty($ord['payment_proof'])): ?>
                                        <button onclick="viewProof('../../assets/uploads/payments/<?= htmlspecialchars($ord['payment_proof']) ?>')" class="text-xs text-indigo-600 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg font-medium flex items-center">
                                            <i class="fa-solid fa-receipt mr-1.5"></i> View Juice Payment Proof
                                        </button>
                                    <?php else: ?>
                                        <span class="text-xs text-gray-400 italic">No payment proof uploaded</span>
                                    <?php endif; ?>

                                    <!-- Change Status Form -->
                                    <div class="flex items-center gap-2 w-full sm:w-auto">
                                        <form method="POST" class="flex items-center gap-2 w-full sm:w-auto">
                                            <input type="hidden" name="action" value="update_order_status">
                                            <input type="hidden" name="order_id" value="<?= $ord['id'] ?>">
                                            <select name="status" class="text-xs border border-gray-300 rounded-lg px-2.5 py-1.5 bg-white focus:ring-2 focus:ring-indigo-500 outline-none">
                                                <option value="Pending Verification" <?= $status === 'Pending Verification' ? 'selected' : '' ?>>Pending Verification</option>
                                                <option value="Processing" <?= $status === 'Processing' ? 'selected' : '' ?>>Processing</option>
                                                <option value="Out for Delivery" <?= $status === 'Out for Delivery' ? 'selected' : '' ?>>Out for Delivery</option>
                                                <option value="Delivered" <?= $status === 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                                                <option value="Cancelled" <?= $status === 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                                <option value="Refunded" <?= $status === 'Refunded' ? 'selected' : '' ?>>Refunded</option>
                                            </select>
                                            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white text-xs px-3 py-1.5 rounded-lg font-medium transition">Update</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                    <?php endforeach;
                    endif; ?>
                </div>
            </div>

            <!-- TAB 2: MANAGE DELIVERY RATES & FULFILLMENT -->
            <div id="tab-delivery" class="tab-content hidden space-y-4 sm:space-y-6">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <h2 class="text-lg sm:text-xl font-bold text-gray-800">Delivery Methods & Shipping Rates</h2>
                    <button onclick="openFulfillmentModal()" class="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition shadow flex items-center justify-center"><i class="fa-solid fa-plus mr-1.5"></i> Add Delivery Method</button>
                </div>

                <div class="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b">
                                <th class="p-4">Code</th>
                                <th class="p-4">Method Name</th>
                                <th class="p-4">Fee (Rs)</th>
                                <th class="p-4">Description</th>
                                <th class="p-4">Status</th>
                                <th class="p-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-sm">
                            <?php if (empty($fulfillmentMethods)): ?>
                                <tr>
                                    <td colspan="6" class="p-6 text-center text-gray-500">No delivery methods defined yet.</td>
                                </tr>
                                <?php else: foreach ($fulfillmentMethods as $fm): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="p-4 font-mono font-semibold text-indigo-600"><?= htmlspecialchars($fm['code']) ?></td>
                                        <td class="p-4 font-bold text-gray-800"><?= htmlspecialchars($fm['name']) ?></td>
                                        <td class="p-4 text-emerald-600 font-semibold"><?= (float)$fm['fee'] == 0 ? 'Free' : 'Rs ' . number_format($fm['fee'], 2) ?></td>
                                        <td class="p-4 text-gray-600 text-xs"><?= htmlspecialchars($fm['description'] ?? '') ?></td>
                                        <td class="p-4">
                                            <span class="px-2.5 py-1 text-xs rounded-full font-medium <?= $fm['is_active'] ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' ?>">
                                                <?= $fm['is_active'] ? 'Active' : 'Disabled' ?>
                                            </span>
                                        </td>
                                        <td class="p-4 text-right">
                                            <button onclick='openEditFulfillmentModal(<?= json_encode($fm) ?>)' class="text-indigo-600 hover:text-indigo-900 bg-indigo-50 px-3 py-1.5 rounded-lg text-xs font-medium"><i class="fa-solid fa-pen-to-square"></i> Edit</button>
                                        </td>
                                    </tr>
                            <?php endforeach;
                            endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- TAB 3: PRODUCTS CATALOG -->
            <div id="tab-products" class="tab-content hidden space-y-4 sm:space-y-6">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <h2 class="text-lg sm:text-xl font-bold text-gray-800">Product Catalog & Stock</h2>
                    <button onclick="openProductModal()" class="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition shadow flex items-center justify-center"><i class="fa-solid fa-plus mr-1.5"></i> Add Product</button>
                </div>

                <div class="hidden md:block bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b">
                                <th class="p-4">Image</th>
                                <th class="p-4">Name</th>
                                <th class="p-4">Price</th>
                                <th class="p-4">Stock (S / M / L)</th>
                                <th class="p-4">Status</th>
                                <th class="p-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-sm">
                            <?php if (empty($products)): ?>
                                <tr>
                                    <td colspan="6" class="p-6 text-center text-gray-500">No products found.</td>
                                </tr>
                                <?php else: foreach ($products as $p):
                                    $sizesData = is_array($p['sizes'] ?? null) ? $p['sizes'] : (json_decode($p['sizes'] ?? '{}', true) ?: ['S' => 0, 'M' => 0, 'L' => 0]);
                                    $isSold = ($p['status'] ?? 'available') === 'sold';
                                ?>
                                    <tr class="hover:bg-gray-50 <?= $isSold ? 'opacity-60 bg-gray-50' : '' ?>">
                                        <td class="p-4">
                                            <?php if (!empty($p['image'])): ?>
                                                <img src="<?= htmlspecialchars($p['image']) ?>" alt="" class="w-12 h-12 object-cover rounded-lg border">
                                            <?php else: ?>
                                                <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400"><i class="fa-solid fa-image"></i></div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-4 font-semibold text-gray-800"><?= htmlspecialchars($p['name']) ?></td>
                                        <td class="p-4 text-emerald-600 font-medium">Rs <?= number_format($p['price'], 2) ?></td>
                                        <td class="p-4">
                                            <span class="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs font-mono mr-1">S: <?= $sizesData['S'] ?? 0 ?></span>
                                            <span class="bg-emerald-50 text-emerald-700 px-2 py-1 rounded text-xs font-mono mr-1">M: <?= $sizesData['M'] ?? 0 ?></span>
                                            <span class="bg-purple-50 text-purple-700 px-2 py-1 rounded text-xs font-mono">L: <?= $sizesData['L'] ?? 0 ?></span>
                                        </td>
                                        <td class="p-4">
                                            <form method="POST" class="inline">
                                                <input type="hidden" name="action" value="toggle_product_status">
                                                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                                                <input type="hidden" name="status" value="<?= $p['status'] ?? 'available' ?>">
                                                <button type="submit" class="px-2.5 py-1 text-xs rounded-full font-medium <?= $isSold ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700' ?>">
                                                    <?= $isSold ? 'Sold Out' : 'Available' ?>
                                                </button>
                                            </form>
                                        </td>
                                        <td class="p-4 text-right">
                                            <button onclick='openEditProductModal(<?= json_encode($p) ?>)' class="text-indigo-600 hover:text-indigo-900 bg-indigo-50 px-3 py-1.5 rounded-lg text-xs font-medium"><i class="fa-solid fa-pen-to-square"></i> Edit</button>
                                        </td>
                                    </tr>
                            <?php endforeach;
                            endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- TAB 4: SERVICES -->
            <div id="tab-services" class="tab-content hidden space-y-4 sm:space-y-6">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <h2 class="text-lg sm:text-xl font-bold text-gray-800">Salon Services & Fees</h2>
                    <button onclick="openServiceModal()" class="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition shadow flex items-center justify-center"><i class="fa-solid fa-plus mr-1.5"></i> Add Service</button>
                </div>
                <div class="hidden md:block bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b">
                                <th class="p-4">Image</th>
                                <th class="p-4">Service Name</th>
                                <th class="p-4">Price</th>
                                <th class="p-4">Displacement</th>
                                <th class="p-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-sm">
                            <?php if (empty($services)): ?>
                                <tr>
                                    <td colspan="5" class="p-6 text-center text-gray-500">No services found.</td>
                                </tr>
                                <?php else: foreach ($services as $s): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="p-4">
                                            <?php if (!empty($s['image'])): ?>
                                                <img src="<?= htmlspecialchars($s['image']) ?>" alt="" class="w-12 h-12 object-cover rounded-lg border">
                                            <?php else: ?>
                                                <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400"><i class="fa-solid fa-scissors"></i></div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-4 font-semibold text-gray-800"><?= htmlspecialchars($s['name'] ?? $s['title'] ?? '') ?></td>
                                        <td class="p-4 text-emerald-600 font-semibold">Rs <?= number_format($s['price'] ?? 0, 2) ?></td>
                                        <td class="p-4">
                                            <?php if (!empty($s['allows_displacement'])): ?>
                                                <span class="bg-purple-100 text-purple-700 px-2 py-0.5 rounded text-xs">Yes (Rs <?= number_format($s['displacement_fee'] ?? 0, 2) ?>)</span>
                                            <?php else: ?>
                                                <span class="text-gray-400 text-xs">Salon Only</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="p-4 text-right">
                                            <button onclick='openEditServiceModal(<?= json_encode($s) ?>)' class="text-indigo-600 hover:text-indigo-900 bg-indigo-50 px-3 py-1.5 rounded-lg text-xs font-medium"><i class="fa-solid fa-pen-to-square"></i> Edit</button>
                                        </td>
                                    </tr>
                            <?php endforeach;
                            endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- TAB 5: BOOKINGS -->
            <div id="tab-bookings" class="tab-content hidden space-y-4 sm:space-y-6">
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <h2 class="text-lg sm:text-xl font-bold text-gray-800">Client Bookings</h2>
                    <button onclick="openModal('bookingModal')" class="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition shadow flex items-center justify-center"><i class="fa-solid fa-plus mr-1.5"></i> Add Booking</button>
                </div>
                <div class="hidden md:block bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b">
                                <th class="p-4">Client</th>
                                <th class="p-4">Service</th>
                                <th class="p-4">Contact</th>
                                <th class="p-4">People</th>
                                <th class="p-4">Type</th>
                                <th class="p-4">Date</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-sm">
                            <?php if (empty($bookings)): ?>
                                <tr>
                                    <td colspan="6" class="p-6 text-center text-gray-500">No bookings found.</td>
                                </tr>
                                <?php else: foreach ($bookings as $b): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="p-4 font-semibold text-gray-800"><?= htmlspecialchars($b['client_name']) ?></td>
                                        <td class="p-4 text-indigo-600"><?= htmlspecialchars($b['service_name']) ?></td>
                                        <td class="p-4 text-gray-600"><?= htmlspecialchars($b['contact']) ?></td>
                                        <td class="p-4 font-bold text-gray-700"><?= $b['people_count'] ?></td>
                                        <td class="p-4"><span class="px-2.5 py-1 text-xs rounded-full font-medium <?= $b['onsite_visit'] ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700' ?>"><?= $b['onsite_visit'] ? 'On-site' : 'Salon' ?></span></td>
                                        <td class="p-4 text-gray-600"><?= htmlspecialchars($b['booking_date']) ?></td>
                                    </tr>
                            <?php endforeach;
                            endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- TAB 6: USERS -->
            <div id="tab-users" class="tab-content hidden space-y-4 sm:space-y-6">
                <h2 class="text-lg sm:text-xl font-bold text-gray-800">Registered Users</h2>
                <div class="hidden md:block bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider border-b">
                                <th class="p-4">ID</th>
                                <th class="p-4">Username</th>
                                <th class="p-4">Phone</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-sm">
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="3" class="p-6 text-center text-gray-500">No users found.</td>
                                </tr>
                                <?php else: foreach ($users as $u): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="p-4 text-gray-500">#<?= $u['id'] ?></td>
                                        <td class="p-4 font-semibold text-gray-800"><?= htmlspecialchars($u['username']) ?></td>
                                        <td class="p-4 text-gray-600 font-mono"><?= htmlspecialchars($u['phone'] ?? 'N/A') ?></td>
                                    </tr>
                            <?php endforeach;
                            endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- MODAL: PROOF OF PAYMENT VIEWER -->
    <div id="proofModal" class="fixed inset-0 bg-black/70 hidden items-center justify-center p-4 z-50">
        <div class="bg-white rounded-2xl max-w-lg w-full p-4 shadow-2xl relative">
            <div class="flex justify-between items-center mb-3">
                <h3 class="text-base font-bold text-gray-800">Juice Payment Receipt Proof</h3>
                <button onclick="closeModal('proofModal')" class="text-gray-400 hover:text-gray-600 p-1"><i class="fa-solid fa-xmark text-lg"></i></button>
            </div>
            <div class="text-center bg-gray-100 rounded-lg p-2 overflow-hidden max-h-[75vh]">
                <img id="proofImage" src="" alt="Proof Receipt" class="max-h-[70vh] mx-auto object-contain rounded border">
            </div>
        </div>
    </div>

    <!-- MODAL: ADD/EDIT FULFILLMENT METHOD -->
    <div id="fulfillmentModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center p-3 sm:p-4 z-50">
        <div class="bg-white rounded-2xl max-w-md w-full p-4 sm:p-6 shadow-2xl relative">
            <div class="flex justify-between items-center mb-4">
                <h3 id="fulfillmentModalTitle" class="text-base sm:text-lg font-bold text-gray-800">Add Delivery Method</h3>
                <button onclick="closeModal('fulfillmentModal')" class="text-gray-400 hover:text-gray-600 p-1"><i class="fa-solid fa-xmark text-lg"></i></button>
            </div>
            <form action="" method="POST" class="space-y-4">
                <input type="hidden" name="action" id="fulfillmentFormAction" value="add_fulfillment">
                <input type="hidden" name="fulfillment_id" id="fulfillmentId">

                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Code</label>
                    <input type="text" name="code" id="fulfillmentCode" required class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500 font-mono">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Method Name</label>
                    <input type="text" name="name" id="fulfillmentName" required class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Fee (Rs)</label>
                    <input type="number" step="0.01" name="fee" id="fulfillmentFee" required class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-700 mb-1">Description</label>
                    <input type="text" name="description" id="fulfillmentDescription" class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500">
                </div>
                <div class="flex items-center space-x-2 pt-1">
                    <input type="checkbox" name="is_active" value="1" id="fulfillmentIsActive" checked class="rounded text-indigo-600">
                    <label for="fulfillmentIsActive" class="text-xs font-semibold text-gray-700">Active / Visible at Checkout</label>
                </div>
                <div class="flex justify-end space-x-2 pt-2">
                    <button type="button" onclick="closeModal('fulfillmentModal')" class="px-4 py-2 border rounded-lg text-sm text-gray-600">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium">Save Method</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function switchTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('text-indigo-600', 'border-b-2', 'border-indigo-600');
                btn.classList.add('text-gray-500');
            });
            document.getElementById('tab-' + tabId).classList.remove('hidden');
            const activeBtn = document.getElementById('btn-' + tabId);
            activeBtn.classList.remove('text-gray-500');
            activeBtn.classList.add('text-indigo-600', 'border-b-2', 'border-indigo-600');
        }

        function viewProof(imagePath) {
            document.getElementById('proofImage').src = imagePath;
            openModal('proofModal');
        }

        function openFulfillmentModal() {
            document.getElementById('fulfillmentModalTitle').innerText = 'Add Delivery Method';
            document.getElementById('fulfillmentFormAction').value = 'add_fulfillment';
            document.getElementById('fulfillmentId').value = '';
            document.getElementById('fulfillmentCode').value = '';
            document.getElementById('fulfillmentName').value = '';
            document.getElementById('fulfillmentFee').value = '0.00';
            document.getElementById('fulfillmentDescription').value = '';
            document.getElementById('fulfillmentIsActive').checked = true;
            openModal('fulfillmentModal');
        }

        function openEditFulfillmentModal(fm) {
            document.getElementById('fulfillmentModalTitle').innerText = 'Edit Method #' + fm.id;
            document.getElementById('fulfillmentFormAction').value = 'edit_fulfillment';
            document.getElementById('fulfillmentId').value = fm.id;
            document.getElementById('fulfillmentCode').value = fm.code;
            document.getElementById('fulfillmentName').value = fm.name;
            document.getElementById('fulfillmentFee').value = fm.fee;
            document.getElementById('fulfillmentDescription').value = fm.description || '';
            document.getElementById('fulfillmentIsActive').checked = fm.is_active == 1;
            openModal('fulfillmentModal');
        }

        function openModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function closeModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
    </script>
</body>

</html>